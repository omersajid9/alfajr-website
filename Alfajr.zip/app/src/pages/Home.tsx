import Header from '../sections/Header';
import Hero from '../sections/Hero';
import Marquee from '../sections/Marquee';
import Partnership from '../sections/Partnership';
import Products from '../sections/Products';
import Industries from '../sections/Industries';
import Logistics from '../sections/Logistics';
import Contact from '../sections/Contact';
import Footer from '../sections/Footer';

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Header />
      <Hero />
      <Marquee />
      <Partnership />
      <Products />
      <Industries />
      <Logistics />
      <Contact />
      <Footer />
    </main>
  );
}
